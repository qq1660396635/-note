// 导出数据
async function exportUserData() {
    const account = document.getElementById('account').value;
    const password = document.getElementById('password').value;
    
    try {
        const exportData = await IDB.DataManager.exportData(account, password, true, true);
        IDB.DataManager.downloadExportFile(exportData, `backup_${account}_${Date.now()}.json`);
        alert('导出成功！');
    } catch (error) {
        alert('导出失败：' + error.message);
    }
}

// 导入数据
async function importUserData() {
    const account = document.getElementById('account').value;
    const password = document.getElementById('password').value;
    const fileInput = document.getElementById('importFile');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('请选择文件');
        return;
    }
    
    try {
        const jsonData = await IDB.DataManager.readImportFile(file);
        await IDB.DataManager.importData(jsonData, account, password, true);
        alert('导入成功！');
        location.reload(); // 重新加载页面
    } catch (error) {
        alert('导入失败：' + error.message);
    }
}




// 存储游戏数据
async function saveGameData() {
    const gameData = {
        score: 100,
        level: 5,
        progress: 80
    };
    
    // 存储到用户数据区
    await IDB.put('gameState', gameData, 'userdata');
}

// 读取游戏数据
async function loadGameData() {
    // 从用户数据区读取
    const gameData = await IDB.get('gameState', 'userdata');
    
    if (gameData) {
        console.log('游戏数据:', gameData);
        return gameData;
    } else {
        console.log('没有找到游戏数据');
        return null;
    }
}

// 存储用户配置
async function saveUserConfig() {
    const config = {
        theme: 'dark',
        language: 'zh-CN',
        autoSave: true
    };
    
    // 存储到配置数据区
    await IDB.put('userConfig', config, 'configs');
}

// 读取用户配置
async function loadUserConfig() {
    // 从配置数据区读取
    const config = await IDB.get('userConfig', 'configs');
    
    if (config) {
        console.log('用户配置:', config);
        return config;
    } else {
        console.log('没有找到用户配置');
        return null;
    }
}




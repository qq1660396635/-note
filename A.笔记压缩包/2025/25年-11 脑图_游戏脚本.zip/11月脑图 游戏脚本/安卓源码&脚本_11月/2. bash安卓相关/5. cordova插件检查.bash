# 1. 进入项目目录
cd ~/2026

# 2. 移除旧插件
cordova plugin remove cordova-plugin-atomic-export

# 3. 清理并重新添加平台
cordova platform remove android
cordova platform add android@12.0.1 --no-fetch

# 4. 重新安装插件
cordova plugin add plugins/cordova-plugin-atomic-export

# 5. 重新构建
cordova build android

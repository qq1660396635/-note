#!/bin/bash
# ctags 最大火力 → 中文归类 → 一行三列对齐 → 连续序号
set -euo pipefail

read -r -p "请输入要扫描的 C/C++ 文件路径（支持空格）: " SRC
[[ -z "$SRC" ]] && { echo "❌ 路径为空，退出"; exit 1; }
SRC="${SRC%\"}"
SRC="${SRC#\"}"
[[ -f "$SRC" ]] || { echo "❌ 文件不存在：$SRC"; exit 1; }

DIR=$(dirname "$SRC")
BASE=$(basename "$SRC" | sed 's/\.[^.]*$//')
OUT="$DIR/${BASE}_aligned.md"

echo "🔄 正在生成对齐符号列表 ..."
ctags --output-format=json \
  --kinds-c=+c+d+e+f+g+l+m+n+p+s+t+u+v+x \
  --kinds-c++=+c+d+e+f+g+l+m+n+p+s+t+u+v+x \
  --fields=+iafkmnsSt \
  --extras=+F+q+r \
  "$SRC" 2>/dev/null \
| jq -r 'select(.name|startswith("__anon")|not)
         |(.kind+"\t"+.name)' \
| awk -v f="$SRC" '
BEGIN{
  map["f"]="函数"; map["p"]="原型"; map["d"]="宏定义"
  map["s"]="结构体"; map["u"]="联合体"; map["e"]="枚举"
  map["g"]="枚举值"; map["t"]="类型"; map["v"]="变量"
  map["l"]="局部"; map["h"]="头文件"; map["x"]="外部变量"
  PROCINFO["sorted_in"]="@ind_str_asc"   # gawk 排序
}
{
  kind=$1; name=$2
  k=(kind in map ? map[kind] : kind)
  list[k]=list[k] (list[k]==""?"":",") name
}
END{
  print "---"; print "文件: " f; print ""
  idx=0
  for(k in list){
    split(list[k], arr,",")
    printf "%-8s：", k
    for(i=1;i<=length(arr);i++){
      idx++
      printf " %2d. %-25s", idx, arr[i]
      if(i%3==0 && i<length(arr)) printf "\n        "   # 一行三个后换行对齐
    }
    print "\n"
  }
}' > "$OUT"

echo "✅ 对齐符号列表已生成：$OUT"
